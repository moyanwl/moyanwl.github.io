---
layout: page
title: 友链和留言
---
交换友链可以在评论区留言~

- [刻苦驴啊](https://blog.csdn.net/D5__J9)：大哥+舍友，很耐心的解决我很多问题~
- [shadw3002](https://shadw3002.github.io)：同学+基友，常在一起交流技♂术
- [水唐](https://yorkking.github.io)：同学+基友，热爱数学（自称为“紧跟大佬的菜鸡挣扎者”

{% include valine.html %}
