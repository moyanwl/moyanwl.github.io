---
layout: document
title: ICPC模板
---
{% for post in site.tags["ICPC模板"] %}
# {{ post.title }}
{{ post.content }}
{% endfor %}
